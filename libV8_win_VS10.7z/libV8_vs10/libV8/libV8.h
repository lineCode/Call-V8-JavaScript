// libV8.h

#pragma once

// using namespace System;

/*
namespace libV8 {

	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
*/
